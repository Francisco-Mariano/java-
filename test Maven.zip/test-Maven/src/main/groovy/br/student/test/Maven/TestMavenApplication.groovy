package br.student.test.Maven

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class TestMavenApplication {

	static void main(String[] args) {
		SpringApplication.run(TestMavenApplication, args)
	}

}
