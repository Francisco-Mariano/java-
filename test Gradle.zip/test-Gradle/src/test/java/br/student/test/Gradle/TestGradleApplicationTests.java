package br.student.test.Gradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
